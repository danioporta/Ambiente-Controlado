#include "fun.h"

void setup()
{
  //BOMBA1
  dht.begin();
  dht2.begin();
  dht3.begin();
  Serial.begin(115200);
  pinMode(DHTPIN,OUTPUT);
  
  //BOMBA2
  pinMode(DHTPIN2,OUTPUT);

  //BOMBA3
  pinMode(DHTPIN3,OUTPUT);
  
  //HIGROMETRO  
  Serial.begin(115200);


  

}

void imprimirLectura(int *puntero)
{
   
   int porcentaje = map(*puntero, 1023, 0,0, 100);
   Serial.print("La lectura de humedad es: ");
   Serial.print(*puntero); 
   Serial.print(" de 1023 segun los valores de humedad de la tablatura para dht Arduino"); 
   Serial.println(" ");
   
   Serial.print("El porcentaje de la humedad es del: ");
   Serial.print(porcentaje);
   Serial.print("%");
   Serial.println(" ");
   
  
} 
  
   
void condicion(int *puntero){   
  
   int condicion;
   int *ptr;
   ptr=&condicion;

   

 //lectura entre 1000-1023

 if (*puntero>= 1000) {
  Serial.println("El sensor esta desconectado o fuera del suelo");
  Serial.println("Se desactivara el sistema de riego");
  digitalWrite(DHTPIN, LOW);
  *ptr=NO;
  
  
  }
 else if (*puntero<1000 && *puntero>=600)
 {
  Serial.println("El suelo esta seco");
  Serial.println("Se iniciara el sistema de riego");
  digitalWrite(DHTPIN, HIGH);

  delay(SEGHIGH);

  digitalWrite(9, LOW);
  *ptr=SI;
  
  }
 else if(*puntero <600 && *puntero >= 370)
 {
  Serial.println("El suelo esta humedo");
  Serial.println("El sistema de riego se desactivara");
  digitalWrite(DHTPIN, LOW);

  *ptr=SI;
  }
 else if (*puntero <370) {
  Serial.println("El sensor esta sumergido en agua");
  Serial.println("El sistema de riego se desactivara");
  digitalWrite(DHTPIN, LOW);
  *ptr=NO;
  }

  if(*ptr=SI)
  {
    digitalWrite(DHTPIN2, HIGH);
    digitalWrite(DHTPIN3, HIGH);
    delay(SEGSUS);
    digitalWrite(DHTPIN2, LOW);
    digitalWrite(DHTPIN3, LOW);
    Serial.println("Se activara el riego diario de los dos sustratos");
    }
  else if(condicion=NO){
    digitalWrite(DHTPIN2, LOW);
    digitalWrite(DHTPIN3, LOW);
     Serial.println("No se activara el riego diario de los dos sustratos");
    }
  
  
  
  //el sistema de riego se ejecuta una vez al dia
 
}

void loop()
{ 
  int lectura = analogRead(A0);
  int *puntero=&lectura;

  imprimirLectura(puntero);
  condicion(puntero);

  delay(SEGDIA);
  }
