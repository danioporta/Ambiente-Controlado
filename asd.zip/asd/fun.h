#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <stdio.h>
#include <stdbool.h>
#include <Arduino.h>

#define DHTPIN 9
#define DHTTYPE DHT11
#define DHTPIN2 10
#define DHTPIN3 11

#define SI 1
#define NO 0

#define SEGDIA 86400000
#define SEGHIGH 10000
#define SEGSUS 5000

DHT dht(DHTPIN,DHTTYPE);
DHT dht2(DHTPIN,DHTTYPE);
DHT dht3(DHTPIN,DHTTYPE);



void setup();
void loop();
void condicion(int *puntero);
void imprimirLectura(int *puntero);
